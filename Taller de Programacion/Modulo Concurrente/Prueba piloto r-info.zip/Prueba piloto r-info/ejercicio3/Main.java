package ejercicio3;

import rInfo.*;

public class Main {

    public static void main(String[] args) {		
        // Definir áreas
        Area areaR1 = new AreaP(15, 15, 30, 35);
        Area areaR2 = new AreaPC(40, 40, 55, 60);
        Area areaComp = new AreaC(10, 10, 10, 10);
        Area areaFiscal = new AreaP(100,100,100,100);
        
        areaR1.agregarFlores(100);
        areaR2.agregarFlores(100);
        
        // Preparar robots
        Robot rt1 = new RobotRecolector(1); 
        areaR1.agregarRobot(rt1); 
        Robot rt2 = new RobotRecolector(2); 
        areaR2.agregarRobot(rt2); 
        
        areaComp.agregarRobot(rt1);
        areaComp.agregarRobot(rt2);
        
        Robot rf = new RobotFiscal("Fiscal"); 
        areaFiscal.agregarRobot(rf);
        
        rt1.iniciar(15, 15);
        rt2.iniciar(40, 40);
        rf.iniciar(100,100);
    }
    
}
