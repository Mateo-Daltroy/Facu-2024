package ejercicio3;

import rInfo.*;

class RobotRecolector extends Robot {
	public RobotRecolector(int id){
		super(id);
	}
	private int juntarTodasLasFlores(){
            int f = 0;
            while(hayFlorEnLaEsquina()){
		tomarFlor();
		f++;
            }
            return f;
	}
	private int rectangulo(int alto, int ancho){
            int f=0;
            for(int veces=0; veces<2;veces++){
		for(int i=0; i<alto; i++){
                    mover();
                    f = f + juntarTodasLasFlores();
		}
		derecha();
		for(int i=0; i<ancho; i++){
                    mover();
                    f = f + juntarTodasLasFlores();
		}
		derecha();
		}
            return f;
	}
        @Override
	public void comenzar(){
            Mensaje men_ini = recibirMensaje("Fiscal");
            Mensaje men_alto = recibirMensaje("Fiscal");
            int avIni = posAv();
            int caIni = posCa();
            pos(avIni, caIni + men_ini.getMensajeInt());
            int f = rectangulo(men_alto.getMensajeInt(), 15);
		
            for(int i=0; i < f; i++){
		bloquearEsquina(10, 10);
		pos(10, 10);
		depositarFlor();
		pos(avIni, caIni);
		liberarEsquina(10, 10);
            }		
	}
}
