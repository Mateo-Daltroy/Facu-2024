package ejercicio3;

import PaqueteLectura.GeneradorAleatorio;
import rInfo.Robot;

public class RobotFiscal extends Robot{
	public RobotFiscal(String id){
		super(id);
	}
        @Override
	public void comenzar(){
            GeneradorAleatorio.iniciar();
            
            enviarMensaje(1, GeneradorAleatorio.generarInt(9));
            enviarMensaje(2, GeneradorAleatorio.generarInt(9));
            enviarMensaje(1, GeneradorAleatorio.generarInt(9));
            enviarMensaje(2, GeneradorAleatorio.generarInt(9));
	}
}    

