package ejercicio2b;
import rInfo.*;

public class Main {

    public static void main(String[] args) {
        // Definir áreas
        Area areaR1 = new AreaP(2, 2, 5, 7);
        Area areaR2 = new AreaP(6, 2, 8, 10);
        Area areaFiscal = new AreaP(100,100,100,100);
        
        areaR1.agregarFlores(100);
        areaR2.agregarFlores(100);
        
        // Preparar robots
        Robot rt1 = new RobotRecolector(1); 
        areaR1.agregarRobot(rt1); 
        Robot rt2 = new RobotRecolector(2); 
        areaR2.agregarRobot(rt2); 
        
        Robot rf = new RobotFiscal("Fiscal"); 
        areaFiscal.agregarRobot(rf);
        
        rt1.iniciar(2, 2);
        rt2.iniciar(6, 2);
        rf.iniciar(100,100);
    }
    
}
