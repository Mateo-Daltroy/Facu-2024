package ejercicio2b;
import rInfo.*;

public class RobotRecolector extends Robot {
        public RobotRecolector(int id){
		super(id);
	}
	private int juntarTodasLasFlores(){
                int f = 0;
		while(hayFlorEnLaEsquina()){
			tomarFlor();
			f++;
		}
		return f;
	}
	private int rectangulo(int alto, int ancho){
            int f=0;
            for(int veces=0; veces<2;veces++){
		for(int i=0; i<alto; i++){
			f = f + juntarTodasLasFlores();
                        mover();
		}
		derecha();
		for(int i=0; i<ancho; i++){
			f = f + juntarTodasLasFlores();
                        mover();
		}
		derecha();
            }
            return f;
	}
        @Override
	public void comenzar(){
		Mensaje m = recibirMensaje("Fiscal");
		int alto = m.getMensajeInt();
		m = recibirMensaje("Fiscal");
		int ancho = m.getMensajeInt();
		int flores = rectangulo(alto, ancho);
		enviarMensaje("Fiscal", flores);
	}
}
