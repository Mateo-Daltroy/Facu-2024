package ejercicio2b;
import rInfo.*;

public class RobotFiscal extends Robot{
    	public RobotFiscal(String id){
		super(id);
	}
        @Override
	public void comenzar(){
		enviarMensaje(1, 5);
		enviarMensaje(1, 3);
		enviarMensaje(2, 8);
		enviarMensaje(2, 2);
		Mensaje m = recibirMensaje();
		int f = m.getMensajeInt();
		informar("Terminó la tarea el robot " + m.getNombreEmisor());
		m = recibirMensaje();
		f = f + m.getMensajeInt();
		informar("Terminó la tarea el robot " + m.getNombreEmisor());
		informar("Se juntaron" + f + " flores en total");
	}
}
