package ejercicio1ha;

import rInfo.*;

public class Main {

    public static void main(String[] args){
        // Definir áreas
        Area area = new AreaP(2, 2, 5, 7);       
        area.agregarFlores(100);
              
        // Preparar robots
        Robot rc = new RobotRecolector(1); 
        area.agregarRobot(rc); 
            
        // Iniciar el programa
        rc.iniciar(2, 2);
    }
}