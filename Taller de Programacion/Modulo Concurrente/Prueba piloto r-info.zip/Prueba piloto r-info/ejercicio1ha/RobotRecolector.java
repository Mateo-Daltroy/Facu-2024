package ejercicio1ha;

import rInfo.Robot;

public class RobotRecolector extends Robot {

    public RobotRecolector(int id) { 
        super(id); 
    }

    private int tomarFlores(){
        int f = 0;
        while (hayFlorEnLaEsquina()){
            tomarFlor();
            f++;
        }
        return f;
    }
    
    private int rectangulo(int alto, int ancho){
        int f = 0;
        for (int j=0; j < 2; j++) {
            for (int i = 0; i < alto; i++) {
                f = f + tomarFlores();
                mover();
            }
            derecha();
            
            for (int i = 0; i < ancho; i++) {
                f = f + tomarFlores();
                mover();
            }
            derecha();            
        }
        return f;
    }

    @Override
    public void comenzar(){
        int f = rectangulo(5,3);        
        
        informar("Junté " + f + " flores");
    }
}
